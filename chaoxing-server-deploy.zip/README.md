# 学习通作业看板 · 国内服务器部署包

域名：**bianzihaoisgay.icu**（已备案）

---

## 一、买服务器

推荐配置（够用）：

| 项目 | 建议 |
|---|---|
| 厂商 | 阿里云 / 腾讯云「轻量应用服务器」 |
| 地域 | 选离你近的大陆地域（如华东1/上海、华北2/北京） |
| 配置 | 2 核 2G，40GB 系统盘 |
| 镜像 | **Ubuntu 22.04 LTS** |
| 带宽 | 3M 够用（页面很小） |
| 价格 | 新用户约 ¥60–100/年 |

> 买完后在控制台记下 **公网 IP**。

## 二、域名解析

在域名 DNS 服务商处添加两条 A 记录：

| 主机记录 | 类型 | 值 |
|---|---|---|
| `@` | A | 你的服务器公网 IP |
| `www` | A | 你的服务器公网 IP |

> 如果备案是在别的服务商做的，换到阿里云/腾讯云后需要在控制台做一次**接入备案**（免费，1–3 个工作日），否则大陆 80/443 可能被拦。

## 三、放行端口

在服务器控制台「防火墙 / 安全组」放行：

- 22（SSH）
- 80（HTTP）
- 443（HTTPS）

## 四、上传并部署

在本地把 `chaoxing-server-deploy.zip` 上传到服务器：

```powershell
scp chaoxing-server-deploy.zip root@你的服务器IP:/root/
```

登录服务器后执行：

```bash
cd /root
unzip -o chaoxing-server-deploy.zip -d chaoxing
cd chaoxing
sudo bash deploy/setup.sh bianzihaoisgay.icu 你的邮箱@example.com
```

脚本会自动完成：安装 Node 20 → 部署应用 → 注册 systemd 服务 → 配置 Nginx → 申请 HTTPS 证书。

完成后访问：**https://bianzihaoisgay.icu**

## 五、首次登录

打开 https://bianzihaoisgay.icu → 右上角「扫码登录」→ 学习通 App 扫码。
（服务器在国内，扫码登录会比 Cloudflare 稳定很多）

登录成功后 cookie 存在服务器 `/opt/chaoxing/app/data/cookies.json`。

## 六、切换前端地址

部署成功后把这两个地方改成新域名（告诉我，我来改）：

1. 网页静态站 `chaoxing-cloud-site/app.js` 的 `API_BASE`
2. 小程序 `app.js` 的 `baseUrl`

## 七、小程序域名配置

小程序后台 → 开发管理 → 开发设置 → **服务器域名**：

- request 合法域名：`https://bianzihaoisgay.icu`

因为域名已备案，可以正常加入（这是 pages.dev 做不到的）。

## 八、日常维护

| 操作 | 命令 |
|---|---|
| 查看状态 | `systemctl status chaoxing` |
| 查看日志 | `journalctl -u chaoxing -f` |
| 重启 | `systemctl restart chaoxing` |
| 更新代码 | 重新上传覆盖 `/opt/chaoxing/app` 后重启 |

## 目录结构

```text
chaoxing-server-deploy/
├─ app/
│  ├─ server.js          # 后端（零第三方依赖）
│  ├─ public/            # 前端页面
│  └─ data/              # 登录 cookie（运行时生成）
├─ deploy/
│  ├─ setup.sh           # 一键部署脚本
│  ├─ chaoxing.service   # systemd 服务
│  └─ nginx.conf.template
└─ README.md
```
