#!/usr/bin/env node
/**
 * 学习通作业看板 · 本地服务
 * 零第三方依赖，Node 18+
 *
 * 数据来源：
 *   1. mooc1-api.chaoxing.com/mycourse/backclazzdata   课程/班级
 *   2. mooc1-api.chaoxing.com/phone/moocAnalysis/workList  每门课全部作业 + 详情链接
 *   3. stat2-ans.chaoxing.com/work-stastics/stu-works   每门课作业截止时间/状态
 */
'use strict';

import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto, { randomUUID } from 'node:crypto';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '127.0.0.1';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36 Edg/158.0.0.0';
const CACHE_TTL = 5 * 60 * 1000;
const COURSE_CONCURRENCY = 5;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
};

class AuthError extends Error {
  constructor(message) { super(message || '学习通登录态已失效'); this.code = 'AUTH_EXPIRED'; }
}

async function loadCookies() {
  const p = path.join(ROOT, 'data', 'cookies.json');
  try {
    const raw = await fs.readFile(p, 'utf8');
    const list = JSON.parse(raw);
    if (!Array.isArray(list)) throw new Error('cookies.json 格式错误');
    return list;
  } catch (err) {
    throw new AuthError('缺少 data/cookies.json，请先运行 login.bat 登录学习通');
  }
}

function domainMatches(domain, host) {
  const d = String(domain || '').toLowerCase();
  if (!d) return false;
  if (d.startsWith('.')) return host === d.slice(1) || host.endsWith(d);
  return host === d;
}

function cookieHeaderFor(cookies, url) {
  const u = new URL(url);
  const host = u.hostname.toLowerCase();
  const p = u.pathname || '/';
  const now = Date.now();
  return cookies
    .filter((c) => {
      if (c.expires && Number(c.expires) > 0 && Number(c.expires) * 1000 < now) return false;
      if (!domainMatches(c.domain, host)) return false;
      const cp = c.path || '/';
      return p.startsWith(cp);
    })
    .map((c) => c.name + '=' + c.value)
    .join('; ');
}

function decodeEntities(s) {
  return String(s || '')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ');
}
function cleanText(html) {
  return decodeEntities(String(html || '').replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim();
}

async function fetchText(url, cookies, opts = {}) {
  const { referer = 'https://mooc1.chaoxing.com/', accept = 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8', timeout = 20000 } = opts;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const res = await fetch(url, {
      headers: {
        'User-Agent': UA,
        'Accept': accept,
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Cookie': cookieHeaderFor(cookies, url),
        'Referer': referer,
      },
      redirect: 'manual',
      signal: controller.signal,
    });
    if (res.status >= 300 && res.status < 400) {
      throw new AuthError('学习通接口跳转到了登录页，请重新登录');
    }
    if (res.status !== 200) throw new Error('HTTP ' + res.status + ' @ ' + url);
    return await res.text();
  } finally {
    clearTimeout(timer);
  }
}

async function fetchJson(url, cookies, opts) {
  const text = await fetchText(url, cookies, opts);
  try { return JSON.parse(text); }
  catch { throw new Error('接口返回非 JSON: ' + text.slice(0, 80)); }
}

async function mapLimit(items, limit, fn) {
  const out = new Array(items.length);
  let cursor = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      out[index] = await fn(items[index], index);
    }
  });
  await Promise.all(workers);
  return out;
}

async function fetchCourses(cookies) {
  const url = 'https://mooc1-api.chaoxing.com/mycourse/backclazzdata?view=json&getTchClazzType=1&mcode=';
  const data = await fetchJson(url, cookies, { referer: 'https://i.chaoxing.com/', accept: 'application/json, text/plain, */*' });
  if (!data || data.result !== 1) {
    throw new AuthError(data && (data.msg || data.errorMsg) || '学习通返回未登录');
  }
  const seen = new Set();
  const courses = [];
  for (const channel of data.channelList || []) {
    const content = channel.content || {};
    const course = (content.course && content.course.data && content.course.data[0]) || {};
    const classId = String(content.id || '');
    const courseId = String(course.id || '');
    if (!classId || !courseId) continue;
    const key = courseId + '|' + classId;
    if (seen.has(key)) continue;
    seen.add(key);
    courses.push({
      name: course.name || content.name || '未命名课程',
      classId,
      courseId,
      cpi: String(content.cpi || course.cpi || ''),
    });
  }
  return courses;
}

function parseWorkListHtml(html) {
  const items = [];
  const re = /<dt\b([^>]*)>([\s\S]*?)<\/dt>/g;
  let match;
  while ((match = re.exec(html))) {
    const attrs = match[1];
    const inner = match[2];
    const dataMatch = attrs.match(/\bdata="([^"]*)"/);
    if (!dataMatch) continue;
    const dataPath = decodeEntities(dataMatch[1]);
    const statusMatch = attrs.match(/\bstatus="([^"]*)"/);
    const title = cleanText((inner.match(/<h3\b[^>]*>([\s\S]*?)<\/h3>/) || [])[1]);
    const date = cleanText((inner.match(/<p\b[^>]*>([\s\S]*?)<\/p>/) || [])[1]);
    const action = cleanText((inner.match(/<b\b[^>]*>([\s\S]*?)<\/b>/) || [])[1]);
    const q = new URLSearchParams(dataPath.split('?')[1] || '');
    items.push({
      wrId: q.get('taskrefId') || '',
      title,
      publishDate: date,
      actionText: action,
      httpStatus: statusMatch ? statusMatch[1] : '',
      link: dataPath ? 'https://mooc1-api.chaoxing.com' + (dataPath.startsWith('/') ? '' : '/') + dataPath : '',
    });
  }
  return items;
}

function approvalOf(statusCode, statusText) {
  const text = String(statusText || '');
  if (statusCode === 4 || /已完成|已批阅|已评分/.test(text)) return '已批阅';
  if (statusCode === 3 || /待批阅|待评分/.test(text)) return '待批阅';
  if (statusCode === 2) return '已过期';
  return '未批阅';
}

async function fetchCourseWorks(course, cookies) {
  const base = 'https://mooc1-api.chaoxing.com';
  const workListUrl = base + '/phone/moocAnalysis/workList?courseId=' + encodeURIComponent(course.courseId) + '&classId=' + encodeURIComponent(course.classId);
  const statUrl = 'https://stat2-ans.chaoxing.com/work-stastics/stu-works?page=1&pageSize=100&courseid=' + encodeURIComponent(course.courseId) + '&clazzid=' + encodeURIComponent(course.classId) + '&cpi=' + encodeURIComponent(course.cpi) + '&personId=' + encodeURIComponent(course.cpi) + '&ut=s';
  const statReferer = 'https://stat2-ans.chaoxing.com/stat2/work-stastics/stu-index?courseid=' + encodeURIComponent(course.courseId) + '&clazzid=' + encodeURIComponent(course.classId) + '&cpi=' + encodeURIComponent(course.cpi) + '&ut=s';

  const [workListResult, statResult] = await Promise.allSettled([
    fetchText(workListUrl, cookies, { referer: 'https://mooc1.chaoxing.com/' }),
    fetchJson(statUrl, cookies, { referer: statReferer, accept: 'application/json, text/javascript, */*; q=0.01' }),
  ]);

  if (workListResult.status === 'rejected' && workListResult.reason instanceof AuthError) throw workListResult.reason;
  if (statResult.status === 'rejected' && statResult.reason instanceof AuthError) throw statResult.reason;

  const htmlItems = workListResult.status === 'fulfilled' ? parseWorkListHtml(workListResult.value) : [];
  const statItems = statResult.status === 'fulfilled' && statResult.value && Array.isArray(statResult.value.data) ? statResult.value.data : [];
  const linkById = new Map(htmlItems.map((item) => [item.wrId, item]));
  const works = [];
  const used = new Set();

  for (const s of statItems) {
    const id = String(s.wrId || '');
    const h = linkById.get(id);
    used.add(id);
    works.push({
      id: id || String(s.workId || s.title),
      title: cleanText(s.title || (h && h.title) || '未命名作业'),
      courseName: course.name,
      classId: course.classId,
      courseId: course.courseId,
      cpi: course.cpi,
      publishAt: Number(s.beginTimeLong) > 0 ? Number(s.beginTimeLong) : null,
      publishText: s.beginDate || '',
      deadline: Number(s.endTimeLong) > 0 ? Number(s.endTimeLong) : null,
      deadlineText: s.endDate || '',
      statusText: s.statusStr || (h && h.actionText) || '',
      statusCode: Number(s.status) || 0,
      // 学习通作业状态：2=已过期未交，3=待批阅，4=已完成，8=未查看；3/4/6/7 均视为已提交
      submitted: [3, 4, 6, 7].includes(Number(s.status)),
      approval: approvalOf(Number(s.status) || 0, s.statusStr || (h && h.actionText) || ''),
      questionNum: Number(s.questionNum) || 0,
      link: (h && h.link) || '',
      source: 'stat2',
    });
  }

  for (const h of htmlItems) {
    if (used.has(h.wrId)) continue;
    works.push({
      id: h.wrId || h.title,
      title: h.title,
      courseName: course.name,
      classId: course.classId,
      courseId: course.courseId,
      cpi: course.cpi,
      publishAt: null,
      publishText: h.publishDate,
      deadline: null,
      deadlineText: '',
      statusText: h.actionText,
      statusCode: Number(h.httpStatus) || 0,
      submitted: /已完成|待批阅|待评分/.test(h.actionText),
      approval: approvalOf(Number(h.httpStatus) || 0, h.actionText || ''),
      questionNum: 0,
      link: h.link,
      source: 'workList',
    });
  }

  return works;
}

// ---------------------------------------------------------------------------
// 学习通扫码登录（PC 二维码协议）
// ---------------------------------------------------------------------------

const LOGIN_PAGE = 'https://passport2.chaoxing.com/login?fid=&newversion=true&refer=https%3A%2F%2Fi.chaoxing.com';
const QR_SESSIONS = new Map();
const QR_TTL = 5 * 60 * 1000;

class CookieJar {
  constructor() { this.cookies = []; }
  addFromResponse(headers, url) {
    const host = new URL(url).hostname.toLowerCase();
    const list = typeof headers.getSetCookie === 'function' ? headers.getSetCookie() : [];
    for (const raw of list) {
      const parts = String(raw).split(';').map((s) => s.trim()).filter(Boolean);
      if (!parts.length) continue;
      const eq = parts[0].indexOf('=');
      if (eq <= 0) continue;
      const name = parts[0].slice(0, eq).trim();
      const value = parts[0].slice(eq + 1);
      const attrs = {};
      for (const part of parts.slice(1)) {
        const i = part.indexOf('=');
        if (i > 0) attrs[part.slice(0, i).trim().toLowerCase()] = part.slice(i + 1).trim();
        else attrs[part.toLowerCase()] = '';
      }
      let domain = (attrs.domain || host).toLowerCase();
      const cookiePath = attrs.path || '/';
      let expires = -1;
      if (attrs['max-age'] !== undefined) expires = Date.now() / 1000 + Number(attrs['max-age']);
      else if (attrs.expires) expires = Date.parse(attrs.expires) / 1000;
      this.cookies = this.cookies.filter((c) => !(c.name === name && c.domain === domain && c.path === cookiePath));
      this.cookies.push({
        name, value, domain, path: cookiePath,
        expires: Number.isFinite(expires) ? expires : -1,
        httpOnly: Object.prototype.hasOwnProperty.call(attrs, 'httponly'),
        secure: Object.prototype.hasOwnProperty.call(attrs, 'secure'),
      });
    }
  }
  headerFor(url) {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    const p = u.pathname || '/';
    const now = Date.now() / 1000;
    return this.cookies
      .filter((c) => {
        if (c.expires > 0 && c.expires < now) return false;
        const d = String(c.domain || '').toLowerCase();
        const dm = d.startsWith('.') ? (host === d.slice(1) || host.endsWith(d)) : host === d;
        return dm && p.startsWith(c.path || '/');
      })
      .map((c) => c.name + '=' + c.value)
      .join('; ');
  }
  chaoxingCookies() {
    return this.cookies.filter((c) => /(^|\.)chaoxing\.com$/.test(String(c.domain || '').toLowerCase()));
  }
}

async function jarFetch(url, jar, opts = {}) {
  const headers = { ...(opts.headers || {}) };
  const cookie = jar.headerFor(url);
  if (cookie) headers.Cookie = cookie;
  const res = await fetch(url, {
    method: opts.method || 'GET',
    headers,
    body: opts.body,
    redirect: 'manual',
    signal: opts.signal,
  });
  jar.addFromResponse(res.headers, url);
  return res;
}

async function jarFollow(url, jar, maxHops = 10) {
  let current = url;
  for (let i = 0; i < maxHops; i++) {
    const res = await jarFetch(current, jar, { headers: { 'User-Agent': UA, Accept: 'text/html,application/xhtml+xml,*/*' } });
    if (res.status >= 300 && res.status < 400) {
      const loc = res.headers.get('location');
      if (!loc) return res;
      current = new URL(loc, current).toString();
      continue;
    }
    return res;
  }
  return null;
}

function parseHiddenInput(html, id) {
  const tagMatch = html.match(new RegExp('<input[^>]*id="' + id + '"[^>]*>'));
  if (!tagMatch) return '';
  const valueMatch = tagMatch[0].match(/value="([^"]*)"/);
  return valueMatch ? valueMatch[1] : '';
}

async function createQrSession() {
  const jar = new CookieJar();
  const res = await jarFetch(LOGIN_PAGE, jar, { headers: { 'User-Agent': UA, Accept: 'text/html,application/xhtml+xml,*/*' } });
  if (!res.ok) throw new Error('无法打开学习通登录页');
  const html = await res.text();
  let uuid = parseHiddenInput(html, 'uuid');
  let enc = parseHiddenInput(html, 'enc');

  // 与 App/网页一致：先 POST /refreshQRCode 生成新的二维码会话，比页面初始隐藏值更可靠
  try {
    const refreshRes = await jarFetch('https://passport2.chaoxing.com/refreshQRCode', jar, {
      method: 'POST',
      headers: {
        'User-Agent': UA,
        Accept: 'application/json, text/javascript, */*; q=0.01',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        Referer: LOGIN_PAGE,
      },
      body: '',
    });
    const refreshed = JSON.parse(await refreshRes.text());
    if (refreshed && refreshed.uuid && refreshed.enc) {
      uuid = refreshed.uuid;
      enc = refreshed.enc;
    }
  } catch { /* 使用页面初始值兜底 */ }

  if (!uuid || !enc) throw new Error('学习通登录页结构变化，未取到二维码参数');

  const qrRes = await jarFetch('https://passport2.chaoxing.com/createqr?uuid=' + encodeURIComponent(uuid) + '&fid=-1&type=3', jar, {
    headers: { 'User-Agent': UA, Accept: 'image/*,*/*', Referer: LOGIN_PAGE },
  });
  if (!qrRes.ok) throw new Error('二维码获取失败');
  const buf = Buffer.from(await qrRes.arrayBuffer());
  const type = qrRes.headers.get('content-type') || 'image/png';
  const sessionId = randomUUID();
  const session = {
    id: sessionId,
    jar, uuid, enc,
    qr: 'data:' + type + ';base64,' + buf.toString('base64'),
    createdAt: Date.now(),
    status: 'waiting',
    message: '请使用学习通 App 扫描二维码',
  };
  QR_SESSIONS.set(sessionId, session);
  cleanupQrSessions();
  return session;
}

function cleanupQrSessions() {
  const now = Date.now();
  for (const [id, s] of QR_SESSIONS) {
    if (now - s.createdAt > QR_TTL) QR_SESSIONS.delete(id);
  }
}

async function pollQrSession(session) {
  const url = 'https://passport2.chaoxing.com/getauthstatus/v2';
  const body = new URLSearchParams({
    enc: session.enc,
    uuid: session.uuid,
    doubleFactorLogin: '0',
    forbidotherlogin: '0',
  });
  const res = await jarFetch(url, session.jar, {
    method: 'POST',
    headers: {
      'User-Agent': UA,
      Accept: 'application/json, text/javascript, */*; q=0.01',
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      'X-Requested-With': 'XMLHttpRequest',
      Origin: 'https://passport2.chaoxing.com',
      Referer: LOGIN_PAGE,
    },
    body,
  });
  let data;
  try { data = JSON.parse(await res.text()); }
  catch { data = {}; }
  console.log('[QR]', session.id.slice(0, 8), 'type=', data.type, 'status=', data.status, 'msg=', data.mes || data.msg || '');

  if (data.status === true || data.status === 'true') {
    session.status = 'confirming';
    session.message = '扫码成功，正在获取登录凭证...';

    // 登录成功后跟随 SSO 跳转，收集 .chaoxing.com 下的全部 cookie
    const followUrls = [data.url, data.redirectUrl, 'https://i.chaoxing.com', 'http://i.mooc.chaoxing.com/space/index', 'https://passport2.chaoxing.com/mooc/accountManage']
      .filter((u) => typeof u === 'string' && /^https?:\/\//i.test(u));
    for (const followUrl of followUrls) {
      try { await jarFollow(followUrl, session.jar); } catch { /* best effort */ }
    }

    const cookies = session.jar.chaoxingCookies();
    if (!cookies.some((c) => c.name === 'p_auth_token' || c.name === 'cx_p_token')) {
      session.status = 'error';
      session.message = '登录成功但未取到登录票据，请刷新二维码重试。';
      return session;
    }

    try {
      const courses = await fetchCourses(cookies);
      if (!courses.length && !cookies.some((c) => c.name === 'p_auth_token')) throw new AuthError('登录票据无效');
      await saveCookies(cookies);
      session.status = 'success';
      session.message = '登录成功，正在刷新数据...';
    } catch (err) {
      session.status = 'error';
      session.message = '登录成功但读取课程失败：' + String(err && err.message || err);
    }
    return session;
  }

  const type = String(data.type || data.status || '');
  if (type === '4') {
    session.status = 'scanned';
    session.message = '已扫码，请在手机上点击「确认登录」';
  } else if (type === '6') {
    session.status = 'cancelled';
    session.message = '已在手机上取消登录，请重新扫码';
  } else if (type === '2') {
    session.status = 'expired';
    session.message = '二维码已失效，请刷新二维码';
  } else if (type === '7') {
    session.status = 'error';
    session.message = data.mes || data.msg || '登录失败，请重试';
  } else {
    session.status = 'waiting';
    session.message = data.mes && data.mes !== '未登录' ? data.mes : '等待扫码...';
  }
  return session;
}

function aesEncryptLogin(text) {
  const key = Buffer.from('u2oh6Vu^HWe4_AES', 'utf8');
  const cipher = crypto.createCipheriv('aes-128-cbc', key, key);
  return Buffer.concat([cipher.update(Buffer.from(String(text), 'utf8')), cipher.final()]).toString('base64');
}

async function loginWithPassword(username, password) {
  const jar = new CookieJar();
  const body = new URLSearchParams({
    fid: '-1',
    uname: aesEncryptLogin(username),
    password: aesEncryptLogin(password),
    refer: 'https%3A%2F%2Fi.chaoxing.com',
    t: 'true',
    forbidotherlogin: '0',
    validate: '',
  });
  const res = await jarFetch('https://passport2.chaoxing.com/fanyalogin', jar, {
    method: 'POST',
    headers: {
      'User-Agent': UA,
      Accept: 'application/json, text/javascript, */*; q=0.01',
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      'X-Requested-With': 'XMLHttpRequest',
      Referer: 'https://passport2.chaoxing.com/login?fid=&newversion=true&refer=https%3A%2F%2Fi.chaoxing.com',
    },
    body,
  });
  let data = {};
  try { data = JSON.parse(await res.text()); } catch { data = {}; }
  if (data.status !== true && data.status !== 'true') {
    throw new Error(data.msg2 || data.msg || data.mes || '账号或密码错误');
  }
  const followUrls = [data.url, 'https://i.chaoxing.com', 'http://i.mooc.chaoxing.com/space/index', 'https://passport2.chaoxing.com/mooc/accountManage']
    .filter((u) => typeof u === 'string' && /^https?:\/\//i.test(u));
  for (const followUrl of followUrls) {
    try { await jarFollow(followUrl, jar); } catch { /* best effort */ }
  }
  const cookies = jar.chaoxingCookies();
  if (!cookies.some((c) => c.name === 'p_auth_token' || c.name === 'cx_p_token')) {
    throw new Error('登录成功但未取到登录票据，请稍后再试');
  }
  await saveCookies(cookies);
  cache.at = 0;
  return cookies;
}

async function saveCookies(cookies) {
  await fs.mkdir(path.join(ROOT, 'data'), { recursive: true });
  await fs.writeFile(path.join(ROOT, 'data', 'cookies.json'), JSON.stringify(cookies, null, 2));
  let lines = ['# Netscape HTTP Cookie File', '# https://curl.haxx.se/rfc/cookie_spec.html', '# This is a generated file! Do not edit.', ''];
  for (const c of cookies) {
    lines.push([c.domain, String(c.domain || '').startsWith('.') ? 'TRUE' : 'FALSE', c.path || '/', c.secure ? 'TRUE' : 'FALSE', Math.floor(c.expires > 0 ? c.expires : 0), c.name, c.value].join('\t'));
  }
  await fs.writeFile(path.join(ROOT, 'data', 'cookies.txt'), lines.join('\n') + '\n');
}

let cache = { at: 0, data: null, days: 14 };


async function collectData(days) {
  const cookies = await loadCookies();
  const courses = await fetchCourses(cookies);
  const results = await mapLimit(courses, COURSE_CONCURRENCY, async (course) => {
    try {
      return { ok: true, works: await fetchCourseWorks(course, cookies) };
    } catch (err) {
      if (err instanceof AuthError) throw err;
      return { ok: false, error: String(err && err.message || err), works: [] };
    }
  });
  const works = results.flatMap((r) => r.works);
  const failedCourses = results.filter((r) => !r.ok).length;
  const now = Date.now();
  const dayStart = (() => {
    const d = new Date(now);
    return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  })();
  const dayEnd = dayStart + 24 * 3600 * 1000;

  const withCourse = works.map((w) => ({ ...w, courseName: w.courseName }));
  const active = withCourse.filter((w) => w.deadline && w.deadline > now).sort((a, b) => a.deadline - b.deadline || a.title.localeCompare(b.title, 'zh-CN'));
  const recent = withCourse.filter((w) => w.deadline && w.deadline <= now && w.deadline >= now - days * 86400000).sort((a, b) => b.deadline - a.deadline);
  const noDeadline = withCourse.filter((w) => !w.deadline).sort((a, b) => (b.publishAt || 0) - (a.publishAt || 0));

  const stats = {
    totalWorks: withCourse.length,
    active: active.length,
    activePending: active.filter((w) => !w.submitted).length,
    dueToday: active.filter((w) => w.deadline >= dayStart && w.deadline < dayEnd).length,
    recent: recent.length,
    recentMissed: recent.filter((w) => !w.submitted).length,
    noDeadline: noDeadline.length,
    courses: courses.length,
    failedCourses,
    days,
    generatedAt: new Date(now).toISOString(),
  };

  return {
    ok: true,
    stats,
    courses: courses.map((c) => ({ name: c.name, courseId: c.courseId, classId: c.classId })),
    active,
    recent,
    noDeadline,
  };
}

async function getData(days) {
  const now = Date.now();
  if (cache.data && cache.days === days && now - cache.at < CACHE_TTL) return cache.data;
  const data = await collectData(days);
  cache = { at: Date.now(), data, days };
  return data;
}

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' });
  res.end(body);
}

async function serveStatic(req, res, pathname) {
  let rel = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  if (rel.includes('..')) { res.writeHead(403); res.end('Forbidden'); return; }
  const file = path.join(ROOT, 'public', rel);
  try {
    const data = await fs.readFile(file);
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Not found');
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://127.0.0.1');
    if (url.pathname === '/api/session') {
      let loggedIn = false;
      let uid = '';
      try {
        const cookies = await loadCookies();
        const hasAuth = cookies.some((c) => c.name === 'p_auth_token' || c.name === 'cx_p_token');
        const uidCookie = cookies.find((c) => c.name === 'UID' || c.name === '_uid');
        const expired = cookies.every((c) => !c.expires || c.expires < 0 || c.expires * 1000 > Date.now());
        loggedIn = hasAuth && expired;
        uid = uidCookie ? uidCookie.value : '';
      } catch { loggedIn = false; }
      sendJson(res, 200, { ok: true, loggedIn, uid });
      return;
    }
    if (url.pathname === '/api/login/password' && req.method === 'POST') {
      const chunks = [];
      let size = 0;
      for await (const chunk of req) {
        size += chunk.length;
        if (size > 1024 * 32) throw new Error('请求体过大');
        chunks.push(chunk);
      }
      let payload = {};
      try { payload = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); } catch { payload = {}; }
      const username = String(payload.username || '').trim();
      const password = String(payload.password || '');
      if (!username || !password) { sendJson(res, 400, { ok: false, error: '请输入账号和密码' }); return; }
      try {
        await loginWithPassword(username, password);
        sendJson(res, 200, { ok: true });
      } catch (err) {
        sendJson(res, 200, { ok: false, error: String(err && err.message || err) });
      }
      return;
    }
    if (url.pathname === '/api/login/qr') {
      const session = await createQrSession();
      sendJson(res, 200, { ok: true, sessionId: session.id, qr: session.qr, expiresIn: 120 });
      return;
    }
    if (url.pathname === '/api/login/status') {
      const sessionId = url.searchParams.get('session') || '';
      const session = QR_SESSIONS.get(sessionId);
      if (!session) {
        sendJson(res, 404, { ok: false, status: 'expired', message: '二维码会话不存在，请刷新二维码' });
        return;
      }
      if (Date.now() - session.createdAt > QR_TTL) {
        session.status = 'expired';
        session.message = '二维码已失效，请刷新二维码';
      } else if (session.status === 'waiting' || session.status === 'scanned') {
        await pollQrSession(session);
      }
      if (session.status === 'success') cache.at = 0;
      sendJson(res, 200, { ok: true, status: session.status, message: session.message });
      return;
    }
    if (url.pathname === '/api/assignments') {
      let days = Number(url.searchParams.get('days') || 14);
      if (!Number.isFinite(days) || days < 1) days = 14;
      days = Math.min(90, Math.round(days));
      if (url.searchParams.get('refresh') === '1') cache.at = 0;
      const data = await getData(days);
      sendJson(res, 200, data);
      return;
    }
    if (url.pathname === '/api/health') {
      sendJson(res, 200, { ok: true, time: new Date().toISOString() });
      return;
    }
    await serveStatic(req, res, url.pathname);
  } catch (err) {
    const status = err && err.code === 'AUTH_EXPIRED' ? 401 : 500;
    sendJson(res, status, { ok: false, code: (err && err.code) || 'ERROR', error: String((err && err.message) || err) });
  }
});

server.on('error', (err) => {
  if (err && err.code === 'EADDRINUSE') {
    console.log('');
    console.log('  端口 ' + PORT + ' 已被占用，看板可能已经在运行。');
    console.log('  → http://127.0.0.1:' + PORT);
    console.log('');
    process.exit(0);
  }
  throw err;
});

server.listen(PORT, HOST, () => {
  console.log('');
  console.log('  学习通作业看板 已启动');
  console.log('  → http://' + (HOST === '0.0.0.0' ? '127.0.0.1' : HOST) + ':' + PORT);
  if (HOST === '0.0.0.0') console.log('  （已监听 0.0.0.0，局域网设备可用本机 IP 访问）');
  console.log('');
});
