#!/usr/bin/env bash
set -e

DOMAIN="${1:-bianzihaoisgay.icu}"
EMAIL="${2:-}"
APP_DIR="/opt/chaoxing"
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "==> 部署域名: $DOMAIN"

if [ "$(id -u)" -ne 0 ]; then
  echo "请用 root 运行：sudo bash deploy/setup.sh $DOMAIN 你的邮箱"
  exit 1
fi

echo "==> 安装基础依赖"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates nginx unzip

if ! command -v node >/dev/null 2>&1 || [ "$(node -v | cut -d. -f1 | tr -d v)" -lt 18 ]; then
  echo "==> 安装 Node.js 20"
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

echo "==> 部署应用文件"
mkdir -p "$APP_DIR"
cp -r "$SRC_DIR/app/." "$APP_DIR/app/"
mkdir -p "$APP_DIR/app/data"

echo "==> 安装 systemd 服务"
cp "$SRC_DIR/deploy/chaoxing.service" /etc/systemd/system/chaoxing.service
systemctl daemon-reload
systemctl enable chaoxing
systemctl restart chaoxing

echo "==> 配置 Nginx"
sed "s/DOMAIN/$DOMAIN/g" "$SRC_DIR/deploy/nginx.conf.template" > /etc/nginx/sites-available/chaoxing.conf
ln -sf /etc/nginx/sites-available/chaoxing.conf /etc/nginx/sites-enabled/chaoxing.conf
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx

echo "==> 申请 HTTPS 证书"
if [ -n "$EMAIL" ]; then
  apt-get install -y certbot python3-certbot-nginx
  certbot --nginx -d "$DOMAIN" -d "www.$DOMAIN" --non-interactive --agree-tos -m "$EMAIL" --redirect || true
else
  echo "未提供邮箱，跳过自动证书。稍后可运行：certbot --nginx -d $DOMAIN -d www.$DOMAIN"
fi

echo ""
echo "部署完成： https://$DOMAIN"
echo "查看服务状态： systemctl status chaoxing"
echo "查看日志： journalctl -u chaoxing -f"
